function bootstrap()
%bootstrap Ensure the MATLAB One-Button Game Minihack Contest Toolkit add-on is installed.
%   Runs as a project startup task. Compares the installed add-on
%   version with the latest published on File Exchange and installs or
%   upgrades as needed. Once installed, the add-on appears in the
%   Add-Ons Manager so users can enable, disable, or uninstall it.
%
%   Distribution details:
%     Add-on name : MATLAB One-Button Game Minihack Contest Toolkit
%     UUID        : f7004f46-dbfc-4d34-a601-337032141bd6

    ADDON_NAME = 'MATLAB One-Button Game Minihack Contest Toolkit';
    ADDON_ID   = 'f7004f46-dbfc-4d34-a601-337032141bd6';

    try
        installOrUpgradeAddon(ADDON_NAME, ADDON_ID);
    catch ME
        warning('minihackContest:BootstrapFailed', ...
                'Could not check/install %s: %s', ADDON_NAME, ME.message);
        installed = installedAddonVersion(ADDON_ID);
        if ~isempty(installed)
            ensureEnabled(ADDON_ID);
            fprintf('Continuing with installed %s %s.\n', ADDON_NAME, installed);
        else
            fprintf('%s is not installed. Install it manually to play.\n', ADDON_NAME);
        end
    end

    printBanner();
    openWorkspaceFiles();
end

function installOrUpgradeAddon(ADDON_NAME, ADDON_ID)
    METADATA_URL = resolveMetadataUrl(ADDON_ID);

    metadata = webread(METADATA_URL, weboptions('ContentType','json','Timeout',30));
    archive  = firstArchive(metadata);
    mltbxUrl      = char(archive.url);
    latestVersion = char(metadata.attributes.version);

    installedVersion = installedAddonVersion(ADDON_ID);
    if ~isempty(installedVersion) && strcmp(installedVersion, latestVersion)
        ensureEnabled(ADDON_ID);
        fprintf('%s %s ready.\n', ADDON_NAME, installedVersion);
        return
    end

    if isempty(installedVersion)
        fprintf('Installing %s %s ...\n', ADDON_NAME, latestVersion);
    else
        fprintf('Upgrading %s: %s -> %s ...\n', ADDON_NAME, installedVersion, latestVersion);
    end

    tmpMltbx = [tempname '.mltbx'];
    cleanupMltbx = onCleanup(@() safeDelete(tmpMltbx));
    websave(tmpMltbx, mltbxUrl);

    matlab.addons.install(tmpMltbx);
    ensureEnabled(ADDON_ID);

    fprintf('Installed %s %s\n', ADDON_NAME, latestVersion);
end

function url = resolveMetadataUrl(addonId)
    url = sprintf('https://addons.mathworks.com/registry/v1/mpm/%s/latest/-/metadata', addonId);
end

function a = firstArchive(metadata)
    if ~isfield(metadata, 'archives') || isempty(metadata.archives)
        error('minihackContest:BootstrapNoArchive', ...
              'Add-on metadata did not include any archives.');
    end
    if iscell(metadata.archives)
        a = metadata.archives{1};
    else
        a = metadata.archives(1);
    end
end

function v = installedAddonVersion(addonId)
    v = '';
    try
        installed = matlab.addons.installedAddons;
        idx = find(strcmp(installed.Identifier, addonId), 1);
        if ~isempty(idx)
            v = char(installed.Version(idx));
        end
    catch
    end
end

function ensureEnabled(addonId)
    try
        if ~matlab.addons.isAddonEnabled(addonId)
            matlab.addons.enableAddon(addonId);
        end
    catch
    end
end

function openWorkspaceFiles()
    try
        proj = currentProject;
    catch
        return
    end
    if isempty(proj); return; end
    files = {'game.m', 'README.md'};
    for k = 1:numel(files)
        target = fullfile(proj.RootFolder, files{k});
        if isfile(target)
            try
                open(target);
            catch
            end
        end
    end
end

function safeDelete(f)
    if isfile(f); delete(f); end
end

function printBanner()
    fprintf('\n');
    fprintf('  Build a one-button game by editing a single file: game.m\n');
    fprintf('\n');
    fprintf('  Two ways to build it:\n');
    fprintf('   - On your own: edit game.m, then run the commands below.\n');
    fprintf('   - With an AI coding agent: launch your agent in this project\n');
    fprintf('     folder and tell it: "Read AGENTS.md and help me build my game."\n');
    fprintf('\n');
    fprintf('  Play:      minihackContest.play\n');
    fprintf('  Validate:  minihackContest.validate\n');
    fprintf('  Submit:    minihackContest.submit\n');
    fprintf('\n');
    fprintf('  See README.md for the contract, idioms, and a worked example.\n');
    fprintf('\n');
end
