# AI agent guide — MATLAB One-Button Game Minihack

Instructions for an AI coding assistant helping a contestant build a
one-button MATLAB game in `game.m` for the MATLAB Minihack
contest.

Your job is to produce a game that validates and plays cleanly on the
first try against a live MATLAB session, while teaching the contract
as you go. Treat this file as authoritative when it conflicts with
your general MATLAB training.

## Pre-flight

Do this once at the start of the conversation, before writing any
game code.

### 1. Check for the MATLAB MCP server

Try any `matlab-mcp` tool call (e.g. `check_matlab_code` on
`game.m`). If it responds, skip to step 3.

### 2. Not installed — walk the user through the MATLAB Agentic Toolkit

Tell them what they're getting: *"I don't have a live connection to
your MATLAB. Without it I can only write code — I can't run it,
static-check it, or verify your game plays. Want me to walk you
through installing the MATLAB Agentic Toolkit? It takes ~5 minutes
and gives me the connection."*

**Then stop and wait for a yes/no answer before doing anything else.**
Do not bundle this offer with game-concept questions, code, or any
other action — the whole point is to get a decision first. Only after
the user replies:

- **Yes** → walk them through the steps below.
- **No / skip** → jump to the "no-MCP path" note at the end of this
  section and continue from there.

If they say yes, walk them through these steps **one at a time**,
waiting for a `done` or an error message between each:

**Step A — Download and install the add-on.** Open this link in a
browser to download the installer:
`https://github.com/matlab/simulink-agentic-toolkit/releases/latest/download/agenticToolkitInstaller.mltbx`

Then in MATLAB, double-click the downloaded
`agenticToolkitInstaller.mltbx` (or drag it into the MATLAB Command
Window). When MATLAB prompts, click **Install**.

**Step B — Run the setup command.** In the MATLAB Command Window:
```matlab
setupAgenticToolkit("install")
```
This is an interactive setup. Don't enumerate the exact prompts or
answers — the installer's ordering and numbering drifts between
versions. Instead, describe intent so the user can match whatever
wording they see:

- When asked which toolkit(s) to install, pick **MATLAB Agentic
  Toolkit**. This contest doesn't need Simulink.
- When asked whether to configure the coding agent now, say yes and
  pick the coding agent the user is running from the list.
- When asked which skill groups to install, pick
  **matlab-app-building**, **matlab-programming**, and
  **matlab-software-development** — that's the installer's default and
  covers `uifigure`, `uiaxes`, callbacks, and general MATLAB idioms.
  (`matlab-core` is always included.) They can add more later by
  re-running the same command.
- When asked whether to run `shareMATLABSession` at the end, say yes.
  That folds Step C into this step; if they decline, they'll need to
  run it manually as Step C.

**This step edits your coding agent's MCP config to register the
MATLAB server.** The write happens partway through — you'll see a
"Writing MCP config" line. If the coding agent's CLI was running at
that point, restart it now so it loads the newly-registered server.
If the CLI is launched fresh after that line printed, no restart is
needed.

**If a restart is required, tell the user before they close the
CLI:** "When you're back, just tell me what game you're thinking of
building — I'll have a live MATLAB connection then, so I can write
the code, run it, validate it against the contest harness, and
iterate with you until it plays cleanly." Otherwise the user comes
back to a blank session with no idea how to resume.

**Known quirk:** if the coding agent's CLI isn't on PATH when setup
runs, you'll see a message that the CLI wasn't found and that skills
will be registered as symlinks instead of plugins. The MCP server
itself still works — this only affects how skills are surfaced. If
skill discovery misbehaves later, have the user add the CLI to PATH
and re-run `setupAgenticToolkit("install")`.

**Step C — Connect the agent to the MATLAB session.** *Skip this
step if the user already said `Y` to the `shareMATLABSession` prompt
at the end of Step B.* Otherwise, in MATLAB:
```matlab
shareMATLABSession()
```
This just updates a session-pointer file the MCP server reads at
tool-call time — no CLI restart required after this step. Either way,
suggest adding this line to their MATLAB
[startup script](https://www.mathworks.com/help/matlab/ref/startup.html)
so the agent reconnects automatically next time.

**Step D — Verify.** Wait for the user to confirm `shareMATLABSession`
returned without error, then retry your MCP tool call from step 1.
If it works, proceed to step 3. If not, ask the user for the exact
error message and troubleshoot. Common issues:
- MATLAB older than R2021a — toolkit requires R2021a+.
- `git` not on PATH — install Git and reopen MATLAB.
- Corporate policy blocking add-on install — user needs admin help.
- MCP tool still not found — the coding agent's CLI may have been
  running when Step B wrote the MCP config and missed the new server
  registration. Ask the user to restart the CLI once.
- Skills not appearing even after restart — the coding agent's CLI
  wasn't on PATH during setup, so skills registered as symlinks
  instead of plugins. Add the CLI to PATH and re-run
  `setupAgenticToolkit`.

If the install can't be completed, tell the user **once** what
you're giving up ("I'll help write the game, but you'll need to run
`minihackContest.validate` and `minihackContest.play` yourself and
paste any errors back so I can fix them") and continue without
asking again.

**No-MCP path.** If MCP is unavailable (declined or install failed),
skip step 3 entirely — you can't run the `which` check without MCP.
Instead:
- Assume the toolbox is present if `minihackContest.prj` exists in
  the working directory (the project's `bootstrap.m` installs it on
  first open). If the user hasn't opened the project yet, tell them
  to do so once before running `validate`/`play`.
- Use the "no-MCP dev loop" (see "The dev loop" section) — you write,
  the user runs, the user pastes output.

### 3. Check that the minihackContest toolbox is installed

Once MCP is available, run this via `evaluate_matlab_code`:
```matlab
~isempty(which('minihackContest.validate'))
```

- Returns `1` (true) → toolbox is installed and on the path. Proceed.
- Returns `0` (false) → toolbox isn't available yet. The starter
  project's `bootstrap.m` auto-installs it when the user opens
  `minihackContest.prj` as a project. Ask them to:
  1. In MATLAB, open `minihackContest.prj` (double-click, or
     `openProject('minihackContest.prj')`).
  2. Watch the Command Window for `Installing MATLAB One-Button Game
     Minihack Contest Toolkit ...` or `... ready.` messages.
  3. Re-run the `which` check.

  If bootstrap ran and failed, the error message printed to the
  Command Window is the useful signal — ask the user to paste it.
  Common causes: no network access to `addons.mathworks.com`,
  MATLAB signed out (need to sign in for File Exchange downloads),
  or firewall blocking the download.

### 4. Build the game

Once steps 1 and 3 are both green (or the no-MCP path is
established), proceed to the contract below.

**With MCP, fetch the contest rules once** and write within them from the
start:
```matlab
rules = webread('https://www.mathworks.com/matlabcentral/communitycontests/api/v1/contests/current/rules_meta');
% rules.max_length       -> character cap (comments excluded)
% rules.banned_functions -> cellstr of disallowed functions
% rules.banned_operators -> cellstr of disallowed operators
```
These are the authoritative limits — don't hardcode or memorize them.
`minihackContest.validate` enforces the same list. (No MCP? Skip the fetch
and lean on `validate`, which reports the exact limit you trip.)

**Before writing anything, read what's already there.** If `game.m`
exists in the working directory, read it first. The user may be
mid-project, iterating on an existing game, or have a specific
starting skeleton they want kept. Only fall back to the skeleton at
the bottom of this file if `game.m` is missing or the user explicitly
asks for a fresh start.

## The contract

`game()` in `game.m` MUST return a scalar struct with three function
handles:

```matlab
g.init(ax)                     -> state
g.update(state, dt, pressed)   -> state
g.render(~, state)             -> (no output)
```

- **`ax`** is a `uiaxes` filling the game window. The harness has
  already configured it with an 800×600 world, `hold on`, hidden axis
  lines/ticks, and default interactivity disabled. Override
  `XLim`/`YLim`/`YDir`/`Color` in `init` only if the game wants
  different world coordinates or a different look.
- **`state`** is anything (usually a struct). It flows between frames:
  `init` returns the first state; `update` returns the next state given
  the previous one, `dt`, and the button.
- **`dt`** is the frame delta in seconds, clamped to `[0.001, 0.050]`.
  Scale every motion by `dt` so the game plays the same on any machine.
- **`pressed`** is a scalar logical — `true` on frames where SPACE or a
  mouse click was fired since the last frame. It's edge-triggered: one
  `true` per tap. There is NO hold or release signal — design every
  mechanic around taps. That is the ONLY input. No keyboard, no mouse
  position, no arrow keys.
- **`render`** updates the graphics objects created in `init`, which
  the game keeps as handles inside `state`. Axes are NOT passed in —
  the first arg is ignored. Do NOT create new graphics here. Do NOT
  call `drawnow` (the harness does it). Do NOT open figures/dialogs,
  read files, or spawn processes.

## Non-negotiable rules

Reject any user request that violates these — explain briefly and offer
a compliant alternative:

- **One button only.** No `KeyPressFcn`, no arrow-key handling, no mouse
  position, no multi-key combos. Just `pressed`.
- **No `drawnow` inside `render`.** The harness owns the tick.
- **No windows or dialogs.** The game runs inside the supplied `uiaxes` —
  don't open a `figure`/`uifigure` or any dialog.
- **No `global` / `persistent`.** State must flow through the `state`
  argument.
- **No `addpath` inside `game.m`.** The game is a single file.
- **`render` must be idempotent** for a given `state`. Calling it twice
  with the same state must not change anything visible.

**Contest limits — character cap, banned functions, banned operators.**
These are hard gates enforced server-side on submit; a game that trips
any is rejected. They live in the `rules` you fetched
(`rules.max_length`, `rules.banned_functions`, `rules.banned_operators`),
and `minihackContest.validate` enforces the same list. Read them from the
rules and keep the game inside them — never hardcode or memorize. The
bans broadly cover filesystem, network, process, Java/MEX, dynamic
dispatch, debugging, dialog, and audio access; `validate` names the exact
function if you trip one.

## Performance idioms (enforce these — they're the difference between a smooth game and a 5fps stutter)

- **Create graphics ONCE in `init`, then only mutate their properties
  in `render`.** Never call `rectangle`, `text`, `line`, `plot`,
  `patch` etc. from `render` or `update`. Store handles in
  `state.graphics.*` or similar.
- **Pool dynamic graphics** for spawnable objects (pipes, asteroids,
  bullets). Create N of them in `init` with `Visible='off'`, toggle
  visibility as they're needed, mutate their `Position`.
- **Every motion must scale by `dt`.** `state.x = state.x + speed * dt`,
  not `state.x = state.x + 5`.
- **Set `HitTest='off', 'PickableParts','none'`** on every graphics
  object you draw, so clicks always reach the button handler.

## The dev loop (follow this, don't skip steps)

### With MCP (preferred)

After you write or edit `game.m`:

1. **Static analyze first**. If you have MATLAB tooling available, run
   the Code Analyzer on `game.m` and fix any error-severity issues.
   Warnings about unused args in stubbed bodies are OK; performance
   and correctness warnings are not.
2. **Validate the contract** by running in MATLAB:
   ```matlab
   cd('<absolute path to this folder>');
   clear game;
   minihackContest.validate;
   ```
   Must print "Validation passed." If it doesn't, fix and re-run. If it
   prints `SKIPPED: character limit and banned functions`, the live
   rules couldn't be fetched, so those checks didn't run — ask the user
   to check their network and MATLAB sign-in, then re-run.
3. **Play it live** with `minihackContest.play`. Wait 3-5 seconds, then
   check that the timer is running (`timerfindall`) and the figure is
   still open. If MATLAB throws an error, read the message from the
   uialert and fix the specific line.
4. **Simulate input** by firing the window's click handler to set the
   edge-triggered flag, then `pause(0.05)` so the next timer tick
   consumes it before you inspect state. Repeat to exercise
   start / play / game-over / restart transitions:
   ```matlab
   fig = findall(groot, 'Type', 'figure', 'Name', 'MATLAB One-Button Game');
   fig.WindowButtonDownFcn(fig, []);
   pause(0.05);
   ```
5. **Clean up** before the next iteration: close figures, stop and
   delete lingering timers.

```matlab
figs = findall(groot,'Type','figure');
for i=1:numel(figs), close(figs(i)); end
t = timerfindall;
for i=1:numel(t), stop(t(i)); delete(t(i)); end
```

Do not report a game as "done" without doing steps 1-3.

### Without MCP (fallback)

When MCP is unavailable, you cannot run static analysis, `validate`,
or `play` yourself. The loop becomes cooperative:

1. **Write or edit `game.m`**. Be extra careful — you get no
   automated feedback, so re-read your own diff before handing off.
   Double-check idiom compliance (dt-scaling, no creation in
   `render`, `HitTest='off'`, banned functions).
2. **Hand off to the user** with the exact commands to run:
   ```matlab
   cd('<absolute path to this folder>');
   clear game;
   minihackContest.validate;
   ```
   Then, if that passes:
   ```matlab
   minihackContest.play;
   ```
3. **Ask them to paste back** the full Command Window output (or the
   uialert text if `play` errors). Don't guess — wait for the paste.
4. **Fix based on their output**, then loop back to step 1.
5. **Cleanup commands to give them** between iterations, if the
   figure or a timer is stuck:
   ```matlab
   figs = findall(groot,'Type','figure');
   for i=1:numel(figs), close(figs(i)); end
   t = timerfindall;
   for i=1:numel(t), stop(t(i)); delete(t(i)); end
   ```

Never claim a game is "done" on the no-MCP path without the user
confirming that `validate` printed "Validation passed." *and* that
`play` ran cleanly for at least a few seconds.

## When to ask the user vs. decide

**Ask the user:**
- Game concept and mechanics (what does the player do, what's the goal)
- Aesthetic direction (bright/dark, palette hints)
- Difficulty curve preferences

**Decide yourself (don't ask):**
- All idiom compliance (pooling, `dt`-scaling, `HitTest`)
- World coordinate size (use 800×600 unless the game demands otherwise)
- Fixed vs. random spawning within reason
- Whether to use `YDir='reverse'` (usually yes for platformer-style
  games so y grows downward like a screen)

## Common failure modes → fix

- **Game runs at 5-10fps** → you're creating graphics in `render` or
  `update`. Move creation to `init`, keep pools of hidden objects.
- **`Unable to resolve the name 'minihackContest.play'`** → toolbox
  isn't on the MATLAB path. Verify with
  `~isempty(which('minihackContest.validate'))`. If false, ask the
  user to open `minihackContest.prj` as a project so `bootstrap.m`
  can install the toolbox (see Pre-flight step 3).
- **`Reference to non-existent field 'x'`** → the user removed the
  `state = struct()` line without initializing every field their
  `update`/`render` reads. Initialize all state fields in `init`.
- **Player teleports through obstacles at high speed** → collision
  check is per-frame AABB; at high `state.scrollSpeed` the obstacle
  may jump the player's box. Either cap speed or do a swept check.
- **Timer keeps running after window closes** → shouldn't happen with
  the current `play.m`, but if you write custom harness code, always
  register `fig.CloseRequestFcn` to stop and delete the timer.

## Publishing the game

Do NOT run submit without the user's explicit go-ahead — it's a public
action. Once the game is polished and validated and the user asks you
to submit, ask them for a title (up to 80 characters), then run it
yourself:

```matlab
cd('<absolute path to this folder>');
minihackContest.submit('title', "<their title>", 'confirm', true);
```

Passing `title` and `confirm` skips the interactive prompts, which you
can't answer over MCP. The user must be signed in to MATLAB. It
validates `game.m` locally, uploads it, and prints the entry URL —
share it with the user. The server re-validates the entry; a game that
draws nothing is rejected. If the user prefers to submit themselves,
they just run `minihackContest.submit` in the Command Window.

## Structure of a typical game.m

Use this skeleton as a starting point when the user asks for a fresh
game. Fill in mechanics, add graphics objects to the pool as needed,
scale motion by `dt`.

```matlab
function g = game()
    g.init   = @initState;
    g.update = @updateState;
    g.render = @renderFrame;
end

function state = initState(ax)
    % World
    state.worldW = 800;
    state.worldH = 600;

    % Player, physics, obstacles, timers, difficulty knobs -- all here.
    state.playerX  = 100;
    state.playerY  = 300;
    state.score    = 0;
    state.started  = false;
    state.gameOver = false;

    % Axes look — harness already set up an 800x600 world with hold on,
    % ticks/axis lines hidden, and interactivity disabled. Only set the
    % game-specific bits here.
    ax.YDir = 'reverse';
    ax.Color = [0.10 0.12 0.18];

    % Create every graphics object here. Store handles in state.g.*
    state.g.player = rectangle(ax, 'Position', [100 300 30 30], ...
        'FaceColor', [1 0.8 0.2], 'EdgeColor', 'none', ...
        'HitTest', 'off', 'PickableParts', 'none');
    state.g.score  = text(ax, 20, 24, 'Score: 0', ...
        'Color', 'w', 'FontSize', 14, ...
        'HitTest', 'off', 'PickableParts', 'none');
    state.g.msg    = text(ax, state.worldW/2, state.worldH/2, '', ...
        'Color', 'w', 'FontSize', 20, ...
        'HorizontalAlignment', 'center', ...
        'HitTest', 'off', 'PickableParts', 'none');
end

function state = updateState(state, dt, pressed)
    if state.gameOver
        if pressed, state = resetRound(state); end
        return
    end
    if ~state.started
        if pressed, state.started = true; end
        return
    end

    % Physics scaled by dt.
    % Spawn / move / collide.
    % Update state.score.
    % Set state.gameOver = true on collision.
end

function renderFrame(~, state)
    % Only mutate existing handles. No creation, no drawnow.
    state.g.player.Position = [state.playerX state.playerY 30 30];
    state.g.score.String = sprintf('Score: %d', floor(state.score));
    % Show/hide state.g.msg based on gameOver / started.
end

function state = resetRound(state)
    % Reset numeric state; preserve graphics handles.
end
```

## Anti-patterns to reject

If the user asks for these, refuse and explain why:

- Multi-key input (arrow keys, WASD): breaks the one-button rule
- Hold-to-act mechanics (hold to fly, hold to charge, release to fire):
  there's no hold signal — offer a tap-based version instead (e.g. tap
  to toggle rising/falling, tap rate builds power)
- Persistent leaderboards, save files: no file I/O allowed
- Any use of `figure` or `uifigure` inside `game.m`
- Copying and adapting non-game MATLAB apps that require GUI callbacks
  beyond the single `pressed` signal
