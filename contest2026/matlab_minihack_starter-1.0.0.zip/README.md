# MATLAB One-Button Game Minihack

## Your task

Build a one-button game in MATLAB. The player has a single input
(SPACE or a mouse click), and everything the game does happens inside a
fixed 800×600 window. You edit exactly one file: `game.m`. The tools
installed by this project let you play it locally, validate it against the
contest rules, and publish it when you're ready.

## How to build it

Your `game()` returns a struct with three function handles:

```matlab
g.init(ax)                    -> state
g.update(state, dt, pressed)  -> state
g.render(~, state)            -> (no output)
```

- **`ax`** is a `uiaxes` filling the game window. The harness has
  already configured it with an 800×600 world, `hold on`, hidden
  axis lines/ticks, and default interactivity disabled. Override
  `XLim`/`YLim`/`YDir`/`Color` in `init` if your game wants different
  world coordinates or a different look.
- **`state`** is anything you want (usually a struct). It flows between
  frames: `init` returns the first state; `update` returns the next
  state given the previous one, `dt`, and the button.
- **`dt`** is the frame delta in seconds, clamped to `[0.001, 0.050]`.
  Scale every motion by `dt` so your game plays the same on any machine.
- **`pressed`** is a logical scalar — `true` on frames where SPACE or a
  mouse click was fired since the last frame. It's edge-triggered: one
  `true` per tap. There's no hold or release signal, so design your
  game around taps. That is the only input you get. No keyboard, no
  mouse position, no arrow keys.
- **`render`** updates the graphics objects you created in `init` (which
  you keep as handles in `state`). Axes are not passed in — reach them
  through your stored handles. Do NOT create new graphics here. You
  don't need to call `drawnow` — the harness does. Do NOT open figures,
  dialogs, or read files.

## A worked example: one-shape jumper

```matlab
function g = game()
    g.init   = @initState;
    g.update = @updateState;
    g.render = @renderFrame;
end

function state = initState(ax)
    % The harness already gave us an 800x600 world and hold on.
    % We just want a screen-y-down orientation and a dark background.
    ax.YDir  = 'reverse';
    ax.Color = [0.10 0.12 0.18];

    state.y        = 300;
    state.velocity = 0;
    state.gravity  = 900;
    state.jump     = -320;

    state.graphics.player = rectangle(ax, ...
        'Position', [200 state.y 30 30], ...
        'FaceColor', [1 0.8 0.2], 'EdgeColor', 'none', ...
        'HitTest', 'off', 'PickableParts', 'none');
end

function state = updateState(state, dt, pressed)
    if pressed
        state.velocity = state.jump;
    end
    state.velocity = state.velocity + state.gravity * dt;
    state.y        = state.y        + state.velocity * dt;
end

function renderFrame(~, state)
    state.graphics.player.Position = [200 state.y 30 30];
end
```


## Idioms worth knowing

**Create graphics once, update them each frame.** Deleting and
re-creating rectangles/text every frame tanks the frame rate. Store
handles in `state` and mutate their properties in `render`:

```matlab
% in init:
state.player = rectangle(ax, 'Position', [400 300 30 30], ...
    'FaceColor', [1 0.8 0.2], 'EdgeColor', 'none');

% in render:
state.player.Position = [state.x state.y 30 30];
```

**Don't let drawn objects eat clicks.** Set `HitTest='off'` and
`PickableParts='none'` on your graphics so clicks always reach the
button handler:

```matlab
rectangle(ax, ..., 'HitTest', 'off', 'PickableParts', 'none');
```

## Constraints

**Game rules.**

- One input: SPACE or mouse click, surfaced as a boolean `pressed` per
  frame. No arrow keys, no mouse position, no other keys.
- No files, no dialogs, no `addpath`, no external data.
- No `global` or `persistent` variables — keep everything in `state`.
- `render` updates the graphics you created in `init`. You don't need
  to call `drawnow` — the harness does.
- Harness targets 30 fps (best-effort). The window is a fixed 800×600
  pixel canvas with a matching 800×600 world by default — override
  `ax.XLim`/`YLim` in `init` if your game wants different world
  coordinates.

**Character cap.** `game.m` must be **≤ 10,000 characters**, comments
excluded.

**Banned functions and operators.** `game.m` runs sandboxed, so a range
of functions and operators are not allowed and will be rejected on
submission.

See the full list here: [contest details](https://www.mathworks.com/matlabcentral/contests/25th-anniversary-contest-prizes-rules.html#onebuttonminihackdetails)

You don't need to memorize it — `minihackContest.validate` checks your
`game.m` against the contest's live rules and tells you exactly what to
fix.

## Commands

```matlab
minihackContest.validate   % check the contract and contest rules
minihackContest.play       % play locally (targets 30 fps)
minihackContest.submit     % publish to the contest
```

Typical loop: edit `game.m`, run `minihackContest.play`, tweak, repeat.
When you're happy, `minihackContest.submit`.

## Submitting

Run `minihackContest.submit`. You must be signed in to MATLAB. It asks
for a title (up to 80 characters) and a confirmation, checks your game,
then uploads it.

## Using an AI coding assistant (optional)

This project ships with `AGENTS.md`, an agent-neutral playbook that
encodes the contest contract, performance idioms, and iteration loop.
If you're using an AI coding assistant (Claude Code, Cursor, Codex,
Gemini, etc.), launch it in this project folder and tell it to read
the playbook and build alongside you:

> *Read `AGENTS.md` and help me build a game where you dodge falling
> asteroids.*

Some agents auto-load `AGENTS.md`; for the rest, the message above is
enough to get started. The playbook tells the agent to iterate against
your live MATLAB session via `minihackContest.validate` and `.play`,
and to never `submit` without your go-ahead.

## Files

- `game.m`               Your game. Edit this.
- `AGENTS.md`            Playbook for AI coding assistants (optional).
- `bootstrap.m`          Auto-installer for the contest tools.
- `minihackContest.prj`  MATLAB Project.
